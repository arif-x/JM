<div class="col-md-12 opsi-jawaban">
<div class="form-check">
<label class="container-tombol">
<input type="radio" class="form-check-input slug-soal" name="optionsRadios" id="optionsRadios1" value="a">
<span class=" checkmark"></span>
<i class="input-frame"></i></label>
<label class="form-check-label" id="label_radio1">Amerika Serikat</label>
</div>
 <div class="form-check">
<label class="container-tombol">
<input type="radio" class="form-check-input slug-soal" name="optionsRadios" id="optionsRadios2" value="b">
<span class=" checkmark"></span>
<i class="input-frame"></i></label>
<label class="form-check-label" id="label_radio2">Filipina</label>
</div>
<div class="form-check">
<label class="container-tombol">
<input type="radio" class="form-check-input slug-soal" name="optionsRadios" id="optionsRadios3" value="c">
<span class=" checkmark"></span>
<i class="input-frame"></i></label>
<label class="form-check-label" id="label_radio3">Brunei Darussalam</label>
</div>
<div class="form-check">
<label class="container-tombol">
<input type="radio" class="form-check-input slug-soal" name="optionsRadios" id="optionsRadios4" value="d">
<span class=" checkmark"></span>
<i class="input-frame"></i></label>
<label class="form-check-label" id="label_radio4">Rusia</label>
</div>
<div class="form-check">
<label class="container-tombol">
<input type="radio" class="form-check-input slug-soal" name="optionsRadios" id="optionsRadios5" value="e">
<span class=" checkmark"></span>
<i class="input-frame"></i></label>
<label class="form-check-label" id="label_radio5">Jerman</label>
</div>


</div>