

<?php $__env->startSection('content'); ?>

<div class="page-content">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h3 class="mb-3">Profil</h3>
                <hr>
                <div>
                    <div class="col-md-12 mb-3">
                        <div class="text-center">
                            <h3>Paket Anda Saat Ini</h3>
                            <div class="mt-1">
                                <?php $__currentLoopData = $paket_aktifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paket_aktif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!empty($paket_aktif->nama_paket)): ?>
                                <h5 class="text-primary mt-1"><?php echo e($paket_aktif->nama_paket); ?><span class="f-14 text-muted"></span></h5>
                                <h5 class="f-16 mb-2">Aktif sampai dengan <?php echo e($paket_aktif->tgl_limit); ?></h5>
                                <?php else: ?>
                                <h5 class="text-primary mt-1">Gratis<span class="f-14 text-muted"></span></h5>
                                <h5 class="f-16 mb-2">Aktif sampai dengan -</h5>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <hr>

                    <ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-akun" aria-selected="true" style="color:black">
                                Profil Akun
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-pass-tab" data-toggle="pill" href="#pills-pass" role="tab" aria-controls="pills-pass" aria-selected="false" style="color:black">
                                Ubah Password
                            </a>
                        </li>
                    </ul>

                    <div class="tab-content mt-3" id="pills-tabContent">

                        <div class="tab-pane fade active show" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                            <form action="<?php echo e(route('user.profil.profil')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <label for="nama_lengkap">Nama Lengkap</label>
                                            <input type="text" class="form-control fw-600" id="nama_lengkap" value="<?php echo e(Auth::user()->nama_lengkap); ?>" name="nama_lengkap">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="no_hp">Nomor HP.</label>
                                            <input type="text" class="form-control fw-600" id="no_hp" value="<?php echo e(Auth::user()->no_hp); ?>" name="no_hp">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label for="id_universitas">Universitas</label>
                                            <select class="form-control" name="id_universitas" id="id_universitas" value="<?php echo e(Auth::user()->id_universitas); ?>">
                                                <option value="" disabled>Pilih</option>
                                                <?php $__currentLoopData = $universitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-inverse-primary btn-fw ml-0 font-weight-bold" type="submit">
                                    Simpan Info Akun
                                </button>
                            </form>
                        </div>

                        <div class="tab-pane fade" id="pills-pass" role="tabpanel" aria-labelledby="pills-pass-tab">
                            <form action="<?php echo e(route('user.profil.password')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="">Password Lama</label>
                                    <input type="password" placeholder="Password Lama" class="form-control fw-600" name="old_password">
                                </div>
                                <div class="form-group">
                                    <label for="">Password Baru</label>
                                    <input type="password" placeholder="Password Baru" class="form-control fw-600" name="new_password">
                                </div>
                                <button class="btn btn-inverse-primary btn-fw ml-0 font-weight-bold">Ganti Password</button>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mandiri\resources\views/user/profil.blade.php ENDPATH**/ ?>