<?php $__env->startComponent('mail::message'); ?>
# Pembayaran Ditolak

The body of your message.
<h3><?php echo e($mailData['title']); ?></h3>
<h3><?php echo e($mailData['body']); ?></h3>

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Button Text
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
  <?php /**PATH D:\Laravel\mandiri\resources\views/mail/pembayaran-ditolak.blade.php ENDPATH**/ ?>