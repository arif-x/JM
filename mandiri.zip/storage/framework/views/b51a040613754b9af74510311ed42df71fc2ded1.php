<?php echo e($slot); ?>

<?php /**PATH D:\Laravel\mandiri\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>