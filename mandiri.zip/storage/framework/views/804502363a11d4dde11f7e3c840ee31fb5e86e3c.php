<?php $__env->startComponent('mail::message'); ?>

<h3><?php echo e($mailData['title']); ?></h3>
<p><?php echo $mailData['body']; ?></p>

Salam,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
  <?php /**PATH D:\Laravel\mandiri\resources\views/mail/pembayaran-dikonfirmasi.blade.php ENDPATH**/ ?>