<?php echo e($slot); ?>

<?php /**PATH D:\Laravel\mandiri\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>