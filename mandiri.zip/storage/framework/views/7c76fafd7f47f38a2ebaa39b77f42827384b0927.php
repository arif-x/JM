

<?php $__env->startSection('content'); ?>

<div class="page-content">
	<div class="col-12 grid-margin stretch-card">
		<div class="card">
			<div class="card-body">
				<?php $__currentLoopData = $soals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<h3>Persiapan Latihan <?php echo e($soal->nama_label); ?></h3>
				<hr class="my-4">
				<div class="row">
					<div class="col-md-12">
						<table class="table table-hover">
							<tr>
								<th class="w-25">Kategori </th>
								<td class="fs-15"><?php echo e($soal->nama_kategori); ?></td>
							</tr>
							<tr>
								<th class="w-25">Jumlah Soal</th>
								<td class="fs-15"><?php echo e($soal->counts); ?> soal</td>
							</tr>
							<tr>
								<th class="w-25">Waktu Mengerjakan</th>
								<td class="fs-15"><?php echo e($soal->counts); ?> menit</td>
							</tr>
						</table>
						<div class="alert alert-warning">
							<strong><i class="mdi mdi-information mr-0"></i> Perhatian!</strong>
							<ol>
								<li> Gunakan browser Google Chrome versi terbaru supaya website dapat diakses dengan lancar tanpa masalah. </li>
								<li> Pastikan tidak ada aktivitas login ke akun anda (pada perangkat lain) saat sedang mengerjakan tryout. </li>
							</ol>
						</div>
						<div class="mt-4 d-flex flex-column flex-sm-row">
							<a type="button" href="<?php echo e(route('user.latihan.kerjakan', $soal->slug)); ?>" class="btn btn-inverse-primary btn-fw mr-0 mr-sm-1 font-weight-bold mb-2 mb-sm-0"><i class="mdi mdi-file-document-edit-outline icon-md"></i> Kerjakan Sekarang </a>
							<button class="btn btn-inverse-danger btn-fw ml-0 ml-sm-1 font-weight-bold"><i class="mdi mdi-cancel icon-md"></i> Batal </button>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mandiri\resources\views/user/persiapan.blade.php ENDPATH**/ ?>