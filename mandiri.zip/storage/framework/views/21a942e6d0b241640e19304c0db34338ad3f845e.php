<?php $__env->startSection('content'); ?>

<div class="page-content d-flex align-items-center justify-content-center">

    <div class="row w-100 mx-0 auth-page">
        <div class="col-md-8 col-xl-6 mx-auto">
            <div class="card">
                <div class="row">
                    <div class="col-md-4 pr-md-0">
                      <div class="auth-left-wrapper">

                      </div>
                  </div>
                  <div class="col-md-8 pl-md-0">
                      <div class="auth-form-wrapper px-4 py-5">
                        <a href="#" class="noble-ui-logo d-block mb-2">Jalur<span>Mandiri</span></a>
                        <h5 class="text-muted font-weight-normal mb-4">Selamat Datang! Verifikasi Email Anda.</h5>
                        <hr>
                        <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            Link Verifikasi Email Telah Dikirim!
                        </div>
                        <?php endif; ?>

                        Mohon Cek Email Anda & Klik Link Yang Telah Dikirim
                        Jika Belum Menerima Email,
                        <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link p-0 m-0 align-baseline">Kirim Ulang Untuk Menerima Email Lagi</button>.
                        </form> Atau 
                        <a href="#" class="text" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout
                          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mandiri\resources\views/auth/verify.blade.php ENDPATH**/ ?>