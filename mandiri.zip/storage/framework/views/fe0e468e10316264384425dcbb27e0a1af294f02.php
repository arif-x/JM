<!DOCTYPE html>
<html>
<head>
    <style type="text/css">
        table, th, td {
            border: 1px solid black;
        }

        table {
            border-collapse: collapse;
        }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal Dikonfirmasi</th>
                <th>Kode</th>
                <th>Nama Paket</th>
                <th>Nama Kategori</th>
                <th>Jenis Kampus</th>
                <th>Bukti Bayar</th>
                <th>Jumlah</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1 ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($data->tgl_dikonfirmasi); ?></td>
                <td><?php echo e($data->kode); ?></td>
                <td><?php echo e($data->nama_paket); ?></td>
                <td><?php echo e($data->nama_kategori); ?></td>
                <td><?php echo e($data->nama_jenis_kampus); ?></td>
                <td><?php echo e($data->bukti_pembayaran); ?></td>
                <td><?php echo e($data->jumlah); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="7">Jumlah</td>
                <td><?php echo e($sum); ?></td>
            </tr>
        </tbody>
    </table>
</body>
</html><?php /**PATH D:\Laravel\mandiri\resources\views/admin/excel/pembayaran.blade.php ENDPATH**/ ?>