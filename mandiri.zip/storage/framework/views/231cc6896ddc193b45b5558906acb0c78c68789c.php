<?php echo e($slot); ?>

<?php /**PATH D:\Laravel\mandiri\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>