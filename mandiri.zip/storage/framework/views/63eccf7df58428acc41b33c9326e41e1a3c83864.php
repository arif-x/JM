

<?php $__env->startSection('content'); ?>

<div class="page-content">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <div>
                    <h3>Hasil Event Tryout <?php echo e($label); ?></h3>
                    <p>Berikut hasil ranking event tryout.</p>
                </div>
                <hr>
                <div class="table-responsive">
                    <table id="dataTableExample" class="table table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Nama</th>
                                <th>Skor</th>
                            </tr>
                        </thead>  
                    </table>
                    <script type="text/javascript">
                        $(function () {
                            $.ajaxSetup({
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                }
                            });
                            var table = $('#dataTableExample').DataTable({
                                processing: true,
                                serverSide: true,
                                paging: true,
                                ajax: "<?php echo e(route('user.event-tryout.hasil', $slugs)); ?>",
                                columns: [
                                {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                                {data: 'nama_lengkap', name: 'nama_lengkap'},
                                {data: 'skor', name: 'skor'},
                                ]
                            });
                        });
                    </script>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mandiri\resources\views/user/tryout-event/hasil.blade.php ENDPATH**/ ?>