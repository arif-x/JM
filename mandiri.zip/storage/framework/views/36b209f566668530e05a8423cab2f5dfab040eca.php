

<?php $__env->startSection('content'); ?>

<div class="page-content">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h3 class="mb-3">Event Tryout</h3>
                <p>Tryout dapat dikerjakan sesuai dengan waktu pelaksanaan dan kode akses yang valid.</p>
                <hr>
                <div data-v-69d2682d="" class="alert alert-warning"><strong data-v-69d2682d=""><i data-v-69d2682d="" class="mdi mdi-information mr-0"></i> Perhatian!</strong> Gunakan browser Google Chrome versi terbaru supaya website dapat diakses dengan lancar tanpa masalah. </div>
                <hr>
                <div class="row">

                    <?php $__currentLoopData = $tps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h4 class="text-primary"><strong><?php echo e($soal->nama_label); ?></strong></h4>
                                Informasi lebih lengkap untuk berpartisipasi dalam event try out ini kunjungi ..... 
                            </div>
                            <div class="card-body">
                                <p class="mb-0 card-text">
                                    Tgl. Mulai: <?php echo e(Carbon\Carbon::parse($soal->tgl_mulai)->locale('id')->dayName); ?>, <?php echo e(date('d', strtotime($soal->tgl_mulai))); ?> <?php echo e(Carbon\Carbon::parse($soal->tgl_mulai)->locale('id')->monthName); ?> <?php echo e(date('Y', strtotime($soal->tgl_mulai))); ?> Pukul 00:00
                                </p>
                                <p class="mt-2 mb-0 card-text">
                                    Tgl. Selesai: <?php echo e(Carbon\Carbon::parse($soal->tgl_end)->locale('id')->dayName); ?>, <?php echo e(date('d', strtotime($soal->tgl_end))); ?> <?php echo e(Carbon\Carbon::parse($soal->tgl_end)->locale('id')->monthName); ?> <?php echo e(date('Y', strtotime($soal->tgl_end))); ?> Pukul 00:00
                                </p>
                                <hr>
                                <div class="row">
                                    <?php if(Carbon\Carbon::now() < $soal->tgl_mulai): ?>
                                    <button class="btn btn-secondary ml-2 font-weight-bold mt-3" disabled>Event Belum Dimulai</button>
                                    <?php elseif(Carbon\Carbon::now() > $soal->tgl_end): ?>
                                    <button class="btn btn-secondary ml-2 font-weight-bold mt-3" disabled>Event Telah Berakhir</button>
                                    <?php elseif(Carbon\Carbon::now()->between($soal->tgl_mulai, $soal->tgl_end)): ?>
                                    <button class="btn btn-inverse-primary ml-2 font-weight-bold mt-3" data-slug="<?php echo e($soal->slug); ?>" onclick="tryoutEvent(this);" id="kerjakan">Kerjakan</button>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('user.event-tryout.hasil', $soal->slug)); ?>" class="btn btn-inverse-primary ml-2 font-weight-bold mt-3">Ranking</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <?php echo $modal; ?>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    function tryoutEvent(obj){
        $('#warningModal').modal('show');
        $('#kerjakanBtn').attr('href', '/user/event-tryout/persiapan/'+$(obj).data('slug'))
        $('#kerjakanInput').val($(obj).data('slug'))
        $('#kerjakanInput').hide()
        $('#formId').attr('action', '/user/event-tryout/persiapan/'+$(obj).data('slug'));
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mandiri\resources\views/user/tryout-event/tryout-event.blade.php ENDPATH**/ ?>