<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
	<p class="text-muted text-center text-md-left">Copyright ©<span id="year"></span> <a href="https://www.jalurmandiri.com" target="_blank">Jalur Mandiri</a>. All rights reserved</p>
</footer>
<script type="text/javascript">
	document.getElementById("year").innerHTML = new Date().getFullYear();
</script><?php /**PATH D:\Laravel\mandiri\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>