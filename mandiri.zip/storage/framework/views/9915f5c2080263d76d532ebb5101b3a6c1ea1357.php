

<?php $__env->startSection('content'); ?>

<div class="page-content">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h2 class="mb-3">Beli Paket</h2>
                <hr>
                <div class="col-md-12 mb-3">
                        <div class="text-center">
                            <h2>Paket Anda Saat Ini</h2>
                            <div class="mt-1">
                                <h3 class="text-primary mt-1">Gratisan<span class="f-14 text-muted"></span></h3>
                                <h5 class="f-16 mb-2">Aktif sampai dengan 19/09/2010</h5>
                            </div>
                        </div>
                </div>
                <hr>
                <section class="section" id="pricing">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">

                                <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade active show" id="Month" role="tabpanel" aria-labelledby="Monthly">
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="pricing-box shadow rounded">
                                                    <h5>Freelancer</h5>

                                                    <div class="mt-4 text-center pb-2">
                                                        <h3 class="text-primary mt-4">$199<span class="f-14 text-muted">/Month</span></h3>
                                                        <h5 class="f-16 mb-2">1,000 Monthly Active Users</h5>
                                                    </div>

                                                    <hr>
                                                    <div class="mt-4 pt-2">
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Verifide work and reviews</p>
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Dedicated accounts managers</p>
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Unlimited proposals</p>
                                                        <p class="mb-2"><i class="mdi mdi-close-box-outline text-danger f-18 mr-2"></i>Project tracking</p>
                                                        <p class="mb-2"><i class="mdi mdi-close-box-outline text-danger f-18 mr-2"></i>Easy payments</p>
                                                    </div>

                                                    <div class="mt-4 pt-3 text-center">
                                                        <a href="" class="btn btn-outline-primary">Start with Floaks</a>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-lg-4">
                                                <div class="pricing-box shadow rounded">
                                                    <div class="pricing-badge">
                                                        <span class="badge">Featured</span>
                                                    </div>
                                                    <h5>Startup</h5>

                                                    <div class="mt-4 text-center pb-2">
                                                        <h3 class="text-primary mt-4">$299<span class="f-14 text-muted">/Month</span></h3>
                                                        <h5 class="f-16 mb-2">5,000 Monthly Active Users</h5>
                                                    </div>

                                                    <hr>
                                                    <div class="mt-4 pt-2">
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Verifide work and reviews</p>
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Dedicated accounts managers</p>
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Unlimited proposals</p>
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Project tracking</p>
                                                        <p class="mb-2"><i class="mdi mdi-close-box-outline text-danger f-18 mr-2"></i>Easy payments</p>
                                                    </div>

                                                    <div class="mt-4 pt-3 text-center">
                                                        <a href="" class="btn btn-primary">Start with Floaks</a>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-lg-4">
                                                <div class="pricing-box shadow rounded">
                                                    <h5>Enterprice</h5>

                                                    <div class="mt-4 text-center pb-2">
                                                        <h3 class="text-primary mt-4">$399<span class="f-14 text-muted">/Month</span></h3>
                                                        <h5 class="f-16 mb-2">10,000 Monthly Active Users</h5>
                                                    </div>
                                                    <hr>
                                                    <div class="mt-4 pt-2">
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Verifide work and reviews</p>
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Dedicated accounts managers</p>
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Unlimited proposals</p>
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Project tracking</p>
                                                        <p class="mb-2"><i class="mdi mdi-check-box-outline text-primary f-18 mr-2"></i>Easy payments</p>
                                                    </div>

                                                    <div class="mt-4 pt-3 text-center">
                                                        <a href="" class="btn btn-outline-primary">Start with Floaks</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mandiri\resources\views/user/test2.blade.php ENDPATH**/ ?>