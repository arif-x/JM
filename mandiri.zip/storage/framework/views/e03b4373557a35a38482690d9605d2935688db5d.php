

<?php $__env->startSection('content'); ?>

<div class="page-content">
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
                <h6 class="card-title">Universitas</h6>
                <div class="card-description">
                    <button class="btn btn-primary" id="tambah">Tambah</button>
                    <button class="btn btn-primary" id="import">Import Excel</button>
                    <a class="btn btn-primary" href="/excel/universitas.xlsm">Download Format Excel</a>
                </div>
                <div class="table-responsive">
                    <table id="dataTableExample" class="table">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Jenis Universitas</th>
                                <th>Nama Universitas</th>
                                <th>Action</th>
                            </tr>
                        </thead>  
                    </table>

                    <div class="modal fade" id="importModal" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="importModalHeading"></h4>
                                </div>
                                <div class="modal-body">
                                    <form id="importForm" method="POST" name="importForm" class="form-horizontal" action="<?php echo e(route('admin.universitas.import')); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group">
                                            <label for="file" class="control-label">File Excel</label>
                                            <input type="file" class="form-control" id="file" name="file" required="">
                                        </div>

                                        <button type="submit" class="btn btn-primary w-100">Import</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="theModal" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="theModalHeading"></h4>
                                </div>
                                <div class="modal-body">
                                    <form id="theForm" name="theForm" class="form-horizontal">
                                        <input type="hidden" name="id_universitas" id="id_universitas">

                                        <div class="form-group">
                                            <label for="id_jenis_kampus" class="control-label">Jenis Universitas/Kampus</label>
                                            <select class="form-control" name="id_jenis_kampus" id="id_jenis_kampus">
                                                <option value="" disabled selected>Pilih</option>
                                                <?php $__currentLoopData = $jenis_kampus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value); ?>"><?php echo e($key); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for="nama_universitas" class="control-label">Nama Universitas</label>
                                            <input type="text" class="form-control" id="nama_universitas" name="nama_universitas" required="">
                                        </div>

                                        <button type="submit" class="btn btn-primary w-100" id="saveBtn" value="create">Simpan</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="modal fade" id="theDeleteModal" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="theModalDeleteHeading"></h4>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="id_universitas" id="id_universitas_delete">
                                    <h4>Ingin Menghapus Data Ini?</h4>
                                    <button type="submit" class="btn btn-danger w-100" id="saveDeteleBtn" value="delete">Hapus</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <script type="text/javascript">
                        $(function () {
                            $.ajaxSetup({
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                }
                            });
                            var table = $('#dataTableExample').DataTable({
                                processing: true,
                                serverSide: true,
                                paging: true,
                                ajax: "<?php echo e(route('admin.universitas.index')); ?>",
                                columns: [
                                {data: 'DT_RowIndex', name: 'DT_RowIndex'},
                                {data: 'nama_jenis_kampus', name: 'nama_jenis_kampus'},
                                {data: 'nama_universitas', name: 'nama_universitas'},
                                {data: 'action', name: 'action'},
                                ]
                            });

                            $('#import').click(function () {
                                $('#importForm').trigger("reset");
                                $('#importModalHeading').html("Import Data");
                                $('#importModal').modal('show');
                            });

                            $('#tambah').click(function () {
                                $('#saveBtn').val("save");
                                $('#id_universitas').val('');
                                $('#theForm').trigger("reset");
                                $('#theModalHeading').html("Tambah Data");
                                $('#theModal').modal('show');
                            });

                            $('body').on('click', '.edit-data', function () {
                                var id_universitas = $(this).data('id');
                                $.get("<?php echo e(route('admin.universitas.index')); ?>" +'/' + id_universitas + '', function (data) {
                                    $('#theModalHeading').html("Edit");
                                    $('#saveBtn').val("save");
                                    $('#id_universitas').val(data.id_universitas);
                                    $('#nama_universitas').val(data.nama_universitas);
                                    $('#id_jenis_kampus').val(data.id_jenis_kampus);
                                    $('#theModal').modal('show');
                                })
                            });

                            $('body').on('click', '.delete-data', function () {
                                var id_universitas = $(this).data('id');
                                $.get("<?php echo e(route('admin.universitas.index')); ?>" +'/' + id_universitas + '', function (data) {
                                    $('#theModalDeleteHeading').html("Hapus");
                                    $('#saveDeteleBtn').val("delete");
                                    $('#id_universitas_delete').val(data.id_universitas);
                                    $('#theDeleteModal').modal('show');
                                })
                            });

                            $('#saveBtn').click(function (e) {
                                e.preventDefault();
                                $(this).html('Simpan');

                                $.ajax({
                                    data: $('#theForm').serialize(),
                                    url: "<?php echo e(route('admin.universitas.store')); ?>",
                                    type: "POST",
                                    dataType: 'json',
                                    success: function (data) {
                                        $('#theForm').trigger("reset");
                                        $('#theModal').modal('hide');
                                        table.draw();
                                    },
                                    error: function (data) {
                                        console.log('Error:', data);
                                        $('#saveBtn').html('Simpan');
                                    }
                                });
                            });

                            $('#saveDeteleBtn').click(function (e) {
                                var id_universitas = $('#id_universitas_delete').val();
                                $.ajax({
                                    type: "DELETE",
                                    url: "<?php echo e(route('admin.universitas.store')); ?>"+'/'+id_universitas,
                                    success: function (data) {
                                        table.draw();
                                        $('#theDeleteModal').modal('hide');
                                    },
                                    error: function (data) {
                                        console.log('Error:', data);
                                    }
                                });
                            });

                        });
                    </script>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mandiri\resources\views/admin/universitas.blade.php ENDPATH**/ ?>