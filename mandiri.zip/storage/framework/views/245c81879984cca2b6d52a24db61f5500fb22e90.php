<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Jalur Mandiri'): ?>
<img src="https://images.tokopedia.net/img/cache/500-square/product-1/2017/9/4/0/0_4fb05e35-6eb7-4849-84c5-60663c0cc1f5_488_583.jpg" class="logo" alt="Jalur Mandiri Logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH D:\Laravel\mandiri\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>