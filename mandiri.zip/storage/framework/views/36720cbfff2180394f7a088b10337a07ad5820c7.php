

<?php $__env->startSection('content'); ?>

<div class="container">
    Welcome, <?php echo e(auth()->guard('admin')->user()->nama_lengkap); ?> <br>
    In the Admin Dashboard.....
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-soal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\mandiri\resources\views/admin-soal/dashboard.blade.php ENDPATH**/ ?>